/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.esprit.form;

import com.codename1.ui.Form;
import com.codename1.ui.Label;
import com.codename1.ui.layouts.BoxLayout;

/**
 *
 * @author iheb
 */
public class InterfacePatient extends Form{
    private Label nomL;
    
    public InterfacePatient(){
        super("Espace Patient",BoxLayout.y());
        onGui();
    }
    
    private void onGui(){
        nomL= new Label();
        nomL.setText(Connecter.getUserConnected().getNom());
        this.addAll(nomL);
    }
    private void addActions(){
        
    }
        
}
