/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.esprit.utils;

/**
 *
 * @author iheb
 */
public class Statics {

    public static final String BASE_URL = "http://localhost:9090";
    
}
